package com.spring.prodotti.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.prodotti.dto.ProdottoDTO;
import com.spring.prodotti.service.ProdottoService;

@RestController // rende questa classe un punto di ingresso in cui si definiscono endpoint
@RequestMapping(path="/prodotti")
public class ProdottoController {
	@Autowired // crea la dipendenza con questo servizio :P
	private ProdottoService service;
	
	@PostMapping(path="/carica", consumes = "application/json") // riceve il json per costruire il prodotto
	public void carica(@RequestBody ProdottoDTO dto) {
		service.carica(dto);
	}
	
	@GetMapping(path="/{id}", produces = "application/json") // ritorna il json del prodotto
	public ProdottoDTO cercaPerId(@PathVariable int id) {// id viene inserito nella path url, per questo va specificato
		return service.cercaPerId(id);
	}
}
